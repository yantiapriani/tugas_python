# Inisialisasi variabel i dengan nilai 1
i = 1

# Perulangan while untuk menghitung angka 1 sampai 15
while i <= 15:
    # Cek apakah nilai i kurang dari atau sama dengan 7
    if i <= 7:
        print(i)
    else:
        print(i)
    # Tambahkan nilai i dengan 1
    i += 1

    # Cek apakah nilai i sama dengan 8
    if i == 8:
        # Melanjutkan perhitungan dari angka 10
        i = 10
